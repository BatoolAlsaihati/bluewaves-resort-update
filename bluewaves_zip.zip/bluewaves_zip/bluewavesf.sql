DROP SCHEMA IF EXISTS BlueWaves;
CREATE DATABASE BlueWaves;
use BlueWaves;

CREATE TABLE `user` (
  `ID` int NOT NULL auto_increment,
  `Fname` char(20) NOT NULL,
  `Mname` char(20) NOT NULL,
  `Lname` char(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE `user_login` (
  `ID` int NOT NULL references ID(user),
  `Username` varchar(20) NOT NULL,
  `User_Password` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE `admin_login` (
  `ID` int NOT NULL references ID(Admin),
  `Username` varchar(20) NOT NULL,
  `admin_Password` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
);

Create table `Admin`(
`ID` int not null primary key auto_increment, 
`Fname` char(20) not null, 
`Lname` char(20) not null,
UNIQUE KEY `composite` (`Fname`, `Lname`) 
);

CREATE TABLE `reservation` (
  `ReservationID` int NOT NULL auto_increment,
  `ReservationDate` date NOT NULL,
  `price` double NOT NULL,
  `User_ID` int NOT NULL,
  `ReservationEvent` varchar(200) NOT NULL,
  PRIMARY KEY (`ReservationID`),
  FOREIGN KEY (`User_ID`) REFERENCES `user` (`ID`) ON DELETE CASCADE
);

CREATE TABLE `payment` (
  `ReservationID` int NOT NULL,
  `total_price` double NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `user_ID` int NOT NULL,
  `Card_Number` Varchar(255),
  `CardEXP` Varchar(255),
  `CCV` varchar(255),
  PRIMARY KEY (`ReservationID`),
  FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`) ON DELETE CASCADE,
  FOREIGN KEY (`user_ID`) REFERENCES `user` (`ID`) ON DELETE CASCADE
);


INSERT INTO `admin`(Fname, Lname) VALUES 
('batool','albinsaad'),
('zahra','alramadan');

INSERT INTO `admin_login` VALUES 
(1, 'batoolsa','B37583t'),
(2, 'zahra_ra','Zahra-88');

INSERT INTO `user` VALUES 
(1,'fatima','rashed','alghtani','fatimahq@hotmail.com','0543678234'),
(2,'reem','ahmed','hafez','reemAH@hotmail.com','0563749122'),
(3,'sarah','hasan','ayad','sarahayad@hotmail.com','0500634582'),
(4,'noor','abdullah','qadir','noor_q@hotmail.com','0522367411'),
(5,'rawan','awad','alenezi','r_alenezi@hotmail.com','0567833245'),
(6,'norah','saleh','fadel','nrahS@hotmail.com','0509812345');

INSERT INTO `reservation`(ReservationDate, price, ReservationEvent, user_ID) VALUES 
('2023-05-11',5000, "Birthday",1),
('2023-02-02',5000,"Birthday" ,2),
('2023-06-07',5000, "Wedding" ,3),
('2024-01-01',5000,"Wedding" ,4),
('2023-09-29',5000,"Wedding" ,5),
('2023-04-05',5000,"Wedding" ,6);

INSERT INTO `payment` VALUES 
(1,6500,'cash','1'),
(2,6500,'cash','2'),
(3,8000,'creditcard','3'),
(4,6000,'cash','4'),
(5,7000,'creditcard','5'),
(6,6000,'creditcard','6');

INSERT INTO `user_login` VALUES 
(1,'fatimah_ra','fatimah-12'),
(2,'r_56','rawan678'),
(3,'sarah66','S12346799s'),
(4,'noorqadir','n00r12'),
(5,'rawan_12','a135790A'),
(6,'N77','N77n77');


 Update user
 set phone_number = 0509812346
 where ID = 6;
 
 Update reservation
 set price = 5100 
 where ReservationID = 1004;
 
 Delete from reservation 
 where ReservationID = 1002;
 
  
 Delete from user 
 where ID = 4;
  DELIMITER $$
  CREATE TRIGGER before_insert_date 
  before insert on reservation
  FOR EACH ROW 
  BEGIN 
  IF(EXISTS( SELECT 1 FROM reservation WHERE ReservationDate = new.ReservationDate )) then 
  signal sqlstate value '45000' SET message_text = 'INSERT FAIL DUE TO DUPLICATE DATE';
  END IF;
  END $$
  DELIMITER ;
  

DROP USER IF EXISTS 'BlueWaves'@'localhost';
CREATE USER 'BlueWaves'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';
GRANT ALL PRIVILEGES ON *.* TO 'BlueWaves'@'localhost' WITH GRANT OPTION;
