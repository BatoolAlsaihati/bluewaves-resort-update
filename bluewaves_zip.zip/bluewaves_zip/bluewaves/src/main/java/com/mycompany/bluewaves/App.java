package com.mycompany.bluewaves;

import javax.swing.JFrame;
import java.awt.*;

import com.mycompany.bluewaves.Screens.BlueWaves;

public class App
{
    public static void main(String[] args)
    {
        BlueWaves mainScreen = new BlueWaves();
        mainScreen.setSize(430, 400); // to set the x-dimension and y-dimension of frame.
        mainScreen.setResizable(false); // To not allow the user to resize the application window.
        mainScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit out of application.
        mainScreen.setLocationRelativeTo(null); // center of the screen.
        mainScreen.setVisible(true); // make frame visible.
        mainScreen.getContentPane().setBackground(Color.decode("#adc5cf")); // set frame background.
        // DisplayDetails d = new DisplayDetails(new ReservationModel());
        // d.setVisible(true);
    }

}
