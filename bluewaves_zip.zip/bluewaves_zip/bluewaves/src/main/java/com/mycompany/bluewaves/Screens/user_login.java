package com.mycompany.bluewaves.Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.mycompany.bluewaves.API.DatabaseManager;

import java.awt.Color;

public class user_login extends javax.swing.JFrame
{
    public user_login()
    {
        this.getContentPane().setBackground(Color.decode("#adc5cf"));
        initComponents();

    }

    RegisterButtonHandler goToCreateAccount = new RegisterButtonHandler();

    private void initComponents()
    {

        userLoginLabel = new javax.swing.JLabel();
        usernameLabel = new javax.swing.JLabel();
        passwordLabel = new javax.swing.JLabel();
        usernameTextField = new javax.swing.JTextField();
        adminLoginButton = new javax.swing.JButton();
        loginButton = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();
        createAccountButton = new javax.swing.JButton();
        welcomeBackLabel = new javax.swing.JLabel();
        passwordField = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("User Login");
        setBackground(new java.awt.Color(173, 197, 207));

        userLoginLabel.setFont(new java.awt.Font("Serif", 1, 26)); // NOI18N
        userLoginLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userLoginLabel.setText("User Login");

        usernameLabel.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        usernameLabel.setText("Username");

        passwordLabel.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        passwordLabel.setText("Password");

        adminLoginButton.setText("Admin Login");
        adminLoginButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                goToAdminLogin(evt);
            }
        });

        loginButton.setText("Login");
        loginButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                loginHandler(evt);
            }
        });

        resetButton.setText("Reset");
        resetButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                resetHandler(evt);
            }
        });

        createAccountButton.setText("Create account");
        createAccountButton.addActionListener(goToCreateAccount);

        welcomeBackLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        welcomeBackLabel.setText("Welcome back !");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING,
                                        false)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout
                                                        .createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                false)
                                                        .addComponent(usernameLabel,
                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                Short.MAX_VALUE)
                                                        .addComponent(passwordLabel,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                63,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, 18)
                                                .addGroup(
                                                        layout.createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(passwordField)
                                                                .addComponent(usernameTextField)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(adminLoginButton,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        114,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(
                                                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(layout
                                                        .createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(loginButton,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                75,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(createAccountButton,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                187,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                layout.createSequentialGroup()
                                                                        .addGap(112, 112,
                                                                                112)
                                                                        .addComponent(resetButton,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                75,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(59, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout
                                .createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
                                        Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(userLoginLabel,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                147,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(27, 27, 27)
                                                .addComponent(welcomeBackLabel,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        95,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(134, 134, 134)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(userLoginLabel,
                                        javax.swing.GroupLayout.PREFERRED_SIZE, 46,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(welcomeBackLabel)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(usernameTextField,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                28,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(usernameLabel))
                                .addPreferredGap(
                                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(passwordLabel)
                                        .addComponent(passwordField,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                28,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING,
                                        false)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout
                                                        .createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(loginButton)
                                                        .addComponent(resetButton))
                                                .addPreferredGap(
                                                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(createAccountButton))
                                        .addComponent(adminLoginButton,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                58,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(39, Short.MAX_VALUE)));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>

    private void loginHandler(java.awt.event.ActionEvent evt)
    {
        String username = usernameTextField.getText();
        String password = new String(passwordField.getPassword());

        int result = DatabaseManager.userLogin(username, password);
        if (result == 0)
        {
            dispose();
            User_Interface userInterface = new User_Interface();
            userInterface.setVisible(true);
            userInterface.setLocationRelativeTo(null);
        }
        else if (result == 1)
        {
            return;
        }
        else
        {
            return;
        }
    }

    private void goToAdminLogin(java.awt.event.ActionEvent evt)
    {
        dispose();
        admin_login b = new admin_login();
        b.getContentPane().setBackground(Color.decode("#adc5cf"));
        b.setVisible(true);
    }

    private class RegisterButtonHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            dispose();
            Register r = new Register();
            r.getContentPane().setBackground(Color.decode("#adc5cf"));
            r.setVisible(true);
        }
    }

    private void resetHandler(java.awt.event.ActionEvent evt)
    {
        usernameTextField.setText("");
        passwordField.setText("");
    }

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify
    private javax.swing.JButton adminLoginButton;
    private javax.swing.JButton loginButton;
    private javax.swing.JButton resetButton;
    private javax.swing.JButton createAccountButton;
    private javax.swing.JLabel userLoginLabel;
    private javax.swing.JLabel usernameLabel;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JLabel welcomeBackLabel;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JTextField usernameTextField;
}
