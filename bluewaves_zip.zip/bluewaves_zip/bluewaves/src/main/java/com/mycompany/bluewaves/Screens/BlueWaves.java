package com.mycompany.bluewaves.Screens;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.JFrame;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class BlueWaves extends JFrame
{
    ButtonHandler buttonHandler = new ButtonHandler();
    private final JLabel label1, label2;
    private final JButton button1, button2;

    public BlueWaves()
    {

        super("BlueWaves"); // frame title
        setLayout(new FlowLayout()); // Layout of the frame

        Icon bw;

        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("bw.png"))
        {
            BufferedImage image = ImageIO.read(in);
            bw = new ImageIcon(image);
        }
        catch (IOException e)
        {
            bw = null;
            e.printStackTrace();
        }

        label1 = new JLabel("Welcome to our application!", bw, SwingConstants.CENTER);
        label1.setHorizontalTextPosition(JLabel.CENTER);
        label1.setVerticalTextPosition(JLabel.BOTTOM);
        label1.setForeground(Color.decode("#234247"));
        label1.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 28));
        add(label1);

        label2 = new JLabel("Please choose what you would like to do: ", SwingConstants.CENTER);
        label2.setHorizontalTextPosition(JLabel.CENTER);
        label1.setVerticalTextPosition(JLabel.BOTTOM);
        label2.setForeground(Color.decode("#234247"));
        label2.setFont(new Font("Serif", Font.PLAIN, 20));
        add(label2);

        button1 = new JButton("  sign in  ");
        button1.setSize(20, 10);
        button1.addActionListener(buttonHandler);
        button1.setToolTipText("Click here to view user sign in page.");
        add(button1);

        button2 = new JButton("  Log in  ");
        button2.setSize(20, 10);
        button2.addActionListener(buttonHandler);
        button2.setToolTipText("Click here to view user log in page.");
        add(button2);

    }

    // public static void main(String[] args)
    // {
    // mainScreen = new BlueWaves();
    // // // Instantiate all frames in this project
    // // DisplayDetails d = new DisplayDetails();
    // // eventframe e = new eventframe();
    // // PaymentDetails p = new PaymentDetails();
    // // DelAdmin da = new DelAdmin();
    // // User_Interface u = new User_Interface();
    // // UserPastReservations upr = new UserPastReservations();
    // // Admin_Interface h = new Admin_Interface();
    // // CreateAdmin a = new CreateAdmin();
    // // EditUserInfo n = new EditUserInfo();

    // // // Set all frames to visible
    // // d.setVisible(true);
    // // e.setVisible(true);
    // // p.setVisible(true);
    // // da.setVisible(true);
    // // u.setVisible(true);
    // // upr.setVisible(true);
    // // h.setVisible(true);
    // // a.setVisible(true);
    // // n.setVisible(true);

    // mainScreen.setSize(430, 400); // to set the x-dimension and y-dimension of frame.
    // mainScreen.setResizable(false); // To not allow the user to resize the application window.
    // mainScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit out of application.
    // mainScreen.setLocationRelativeTo(null); // center of the screen.
    // mainScreen.setVisible(true); // make frame visible.
    // mainScreen.getContentPane().setBackground(Color.decode("#adc5cf")); // set frame background.

    // }

    private class ButtonHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            user_login loginScreen = new user_login();
            Register register = new Register();
            if (button1.getModel().isArmed())
            {
                dispose();
                register.setVisible(true);
                register.setLocationRelativeTo(null);
            }
            if (button2.getModel().isArmed())
            {
                dispose();
                loginScreen.setVisible(true);
                loginScreen.setLocationRelativeTo(null);
            }
        }

    }
}

// String fname = jTextField1.getText();
