package com.mycompany.bluewaves.Models;

public class ReservationModel
{
    String eventDate, EventType, cardNumber, cardName, cardExpMonth, cardExpYear, cardCVV;

    public String getCardNumber()
    {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber)
    {
        this.cardNumber = cardNumber;
    }

    public String getCardName()
    {
        return cardName;
    }

    public void setCardName(String cardName)
    {
        this.cardName = cardName;
    }

    public String getCardExpMonth()
    {
        return cardExpMonth;
    }

    public void setCardExpMonth(String cardExpMonth)
    {
        this.cardExpMonth = cardExpMonth;
    }

    public String getCardExpYear()
    {
        return cardExpYear;
    }

    public void setCardExpYear(String cardExpYear)
    {
        this.cardExpYear = cardExpYear;
    }

    public String getCardCVV()
    {
        return cardCVV;
    }

    public void setCardCVV(String cardCVV)
    {
        this.cardCVV = cardCVV;
    }

    int reservationID, userID;

    public String getEventDate()
    {
        return eventDate;
    }

    public void setEventDate(String eventDate)
    {
        this.eventDate = eventDate;
    }

    public String getEventType()
    {
        return EventType;
    }

    public void setEventType(String eventType)
    {
        EventType = eventType;
    }

    public int getReservationID()
    {
        return reservationID;
    }

    public void setReservationID(int reservationID)
    {
        this.reservationID = reservationID;
    }

    public int getUserID()
    {
        return userID;
    }

    public void setUserID(int userID)
    {
        this.userID = userID;
    }

    public String getCardExp()
    {
        String date = cardExpYear.trim() + "-" + cardExpMonth.trim() + "-" + "01";
        return date;
    }

}
