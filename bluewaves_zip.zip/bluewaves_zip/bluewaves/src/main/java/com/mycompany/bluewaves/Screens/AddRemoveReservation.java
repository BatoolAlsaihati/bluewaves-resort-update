package com.mycompany.bluewaves.Screens;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import com.mycompany.bluewaves.API.DatabaseManager;
import com.mycompany.bluewaves.Models.ReservationModel;

public class AddRemoveReservation extends javax.swing.JFrame
{

    private ReservationModel reservationInformation;

    public AddRemoveReservation()
    {
        super("Add/Remove Reservation");
        this.getContentPane().setBackground(Color.decode("#adc5cf"));
        initComponents();
    }

    public AddRemoveReservation(ReservationModel givenReservation)
    {
        super("Add/Remove Reservation");
        this.getContentPane().setBackground(Color.decode("#adc5cf"));
        initComponents();
        this.reservationInformation = givenReservation;
        System.out.println("Reservation ID: " + reservationInformation.getReservationID());
        System.out.println("Reservation Date: " + reservationInformation.getEventDate());
        System.out.println("Reservation Type: " + reservationInformation.getEventType());
        fillInfo();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jPanel1 = new javax.swing.JPanel();
        dateLabel = new javax.swing.JLabel();
        eventOptionsLabel = new javax.swing.JLabel();
        totalPriceLabel = new javax.swing.JLabel();
        totalPriceField = new javax.swing.JTextField();
        eventType = new javax.swing.JComboBox<>();
        addButton = new javax.swing.JButton();
        reservationDate = new com.toedter.calendar.JDateChooser();
        removeButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        reservationsTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));

        setBackground(new java.awt.Color(173, 197, 207));
        setForeground(new java.awt.Color(173, 197, 207));

        dateLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        dateLabel.setText("Date:");

        eventOptionsLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        eventOptionsLabel.setText("Event options:");

        totalPriceLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        totalPriceLabel.setText("Total price:");

        totalPriceField.setText("5000SR");
        totalPriceField.setEditable(false);

        eventType.setModel(
                new javax.swing.DefaultComboBoxModel<>(new String[] {"party", "wedding", "engagement", "birthday"}));

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                addReservationHandler(evt);
            }
        });

        removeButton.setText("Cancel");
        removeButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                removeReservationHandler(evt);
            }
        });

        refreshTable();
        jScrollPane2.setViewportView(reservationsTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(126, 126, 126)
                                                                .addComponent(addButton,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE, 102,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(10, 10, 10)
                                                                .addGroup(layout
                                                                        .createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(dateLabel,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 47,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(reservationDate,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 228,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(eventOptionsLabel)
                                                                        .addComponent(eventType,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 228,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(totalPriceLabel)
                                                                        .addComponent(totalPriceField,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 228,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGap(36, 36, 36)
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(35, 35, 35)
                                                                .addComponent(removeButton,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE, 102,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addComponent(jLabel1))
                                .addContainerGap(30, Short.MAX_VALUE)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(dateLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(reservationDate, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(eventOptionsLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(eventType, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(totalPriceLabel)
                                                .addGap(18, 18, 18)
                                                .addComponent(totalPriceField, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(63, 63, 63)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(removeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(79, Short.MAX_VALUE)));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fillInfo()
    {
        System.out.println("Filling info");
        System.out.println("Reservation is " + this.reservationInformation);
        if (this.reservationInformation != null)
        {
            System.out.println("Reservation is not null");
            try
            {
                System.out.println("Trying....");
                Date date = new SimpleDateFormat("yyyy-MM-dd").parse(this.reservationInformation.getEventDate());
                reservationDate.setDate(date);
                eventType.setSelectedItem(this.reservationInformation.getEventType());
            }
            catch (java.text.ParseException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private void refreshTable()
    {
        TableModel reservations = DatabaseManager.getUsersReservations();
        if (reservations != null)
        {
            reservationsTable.setModel(reservations);
        }
        else
        {
            reservationsTable.setModel(new javax.swing.table.DefaultTableModel(
                    new Object[][] {
                            {null}
                    },
                    new String[] {
                            "No reservations"
                    }));
        }
    }

    private void addReservationHandler(java.awt.event.ActionEvent evt)
    {
        ReservationModel reservation = new ReservationModel();
        // validate date
        if (reservationDate.getDate() == null)
        {
            JOptionPane.showMessageDialog(null, "Please select a date");
            return;
        }
        String date = new SimpleDateFormat("yyyy-MM-dd").format(reservationDate.getDate());
        String type = eventType.getSelectedItem().toString();

        // Validate:
        if (date == null || date.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Please select a date");
            return;
        }
        if (type == null || type.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Please select an event type");
            return;
        }
        reservation.setEventDate(date);
        reservation.setEventType(type);
        reservation.setReservationID(DatabaseManager.getLastReservationID() + 1);

        dispose();
        DisplayDetails paymentDetails = new DisplayDetails(reservation);
        paymentDetails.setVisible(true);
        paymentDetails.setLocationRelativeTo(null);
    }

    private void removeReservationHandler(java.awt.event.ActionEvent evt)
    {
        String reservationID = JOptionPane.showInputDialog("Enter reservation ID");
        if (reservationID == null || reservationID.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "None Found");
            return;
        }
        int check = DatabaseManager.checkID(reservationID);
        if (check == -1)
        {
            return;
        }
        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to Cancel this reservation?");
        if (dialogResult == JOptionPane.YES_OPTION)
        {
            // Remove reservation
            int result = DatabaseManager.removeReservation(reservationID);
            if (result == 0)
            {
                JOptionPane.showMessageDialog(null, "Reservation Cancelled successfully");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Reservation Cancellation failed");
            }
            refreshTable();
        }
    }

    private javax.swing.JButton addButton;
    private javax.swing.JButton removeButton;
    private javax.swing.JComboBox<String> eventType;
    private com.toedter.calendar.JDateChooser reservationDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel eventOptionsLabel;
    private javax.swing.JLabel totalPriceLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable reservationsTable;
    private javax.swing.JTextField totalPriceField;
    // End of variables declaration//GEN-END:variables
}
