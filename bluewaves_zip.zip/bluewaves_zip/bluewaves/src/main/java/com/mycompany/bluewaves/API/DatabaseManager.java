package com.mycompany.bluewaves.API;

import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import com.mycompany.bluewaves.Models.ReservationModel;
import com.mycompany.bluewaves.Models.UserModel;

public class DatabaseManager
{
    private static Connection conn;
    public static int currentUserID;

    public static Connection getConnection()
    {
        try
        {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/BlueWaves", "BlueWaves", "root");
            return conn;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }

    /**
     * @return A user model of the current user
     */
    public static UserModel getCurrentUser()
    {
        conn = getConnection();
        String query = "SELECT * FROM user WHERE ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setInt(1, currentUserID);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            UserModel currentUser = new UserModel();
            currentUser.setFirstName(rs.getString("Fname"));
            currentUser.setMiddleName(rs.getString("Mname"));
            currentUser.setLastName(rs.getString("Lname"));
            currentUser.setEmail(rs.getString("email"));
            currentUser.setPhone(rs.getString("phone_number"));
            currentUser.setUserID(rs.getInt("ID"));
            return currentUser;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    private static int checkUsernameUser(String username)
    {
        // Check if username already exists
        conn = getConnection();
        String query = "SELECT * FROM user_login WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                JOptionPane.showMessageDialog(null, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            else
            {
                return 0;
            }
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        }
    }

    private static int checkUsernameAdmin(String username)
    {
        // Check if username already exists
        conn = getConnection();
        String query = "SELECT * FROM admin_login WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                JOptionPane.showMessageDialog(null, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            else
            {
                return 0;
            }
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        }
    }

    /**
     * @param username
     * @param password
     * @return int 0 if successful, 1 if incorrect username or password, -1 if error
     */
    public static int userLogin(String username, String password)
    {
        conn = getConnection();
        String query = "SELECT * FROM user_login WHERE username = ? AND User_Password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                currentUserID = rs.getInt("ID");
                return 0;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Username or password is incorrect", "Error", JOptionPane.ERROR_MESSAGE);
                return 1;
            }
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        }
    }

    /**
     * @param username
     * @param password
     * @return int 0 if successful, 1 if incorrect username or password, -1 if error
     */
    public static int adminLogin(String username, String password)
    {
        conn = getConnection();
        String query = "SELECT * FROM admin_login WHERE username = ? AND Admin_Password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                currentUserID = rs.getInt("ID");
                return 0;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Username or password is incorrect", "Error", JOptionPane.ERROR_MESSAGE);
                return 1;
            }
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public static int logout()
    {
        currentUserID = 0;
        return 0;
    }

    /**
     * @param firstName
     * @param middleName
     * @param lastName
     * @param username
     * @param email
     * @param password
     * @param phone
     * @return int 0 if successful, 1 if username already exists, -1 if error
     */
    public static int registerUser(String firstName, String middleName, String lastName, String username, String email,
            String password, String phone)
    {
        conn = getConnection();
        int result = checkUsernameUser(username);
        if (result == 1)
        {
            return 1;
        }
        else if (result == -1)
        {
            return -1;
        }

        String queryUser = "INSERT INTO user (Fname, Mname, Lname, email, phone_number) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(queryUser))
        {
            conn.setAutoCommit(false); // Start a transaction
            stmt.setString(1, firstName);
            stmt.setString(2, middleName);
            stmt.setString(3, lastName);
            stmt.setString(4, email);
            stmt.setString(5, phone);
            stmt.executeUpdate();

            // Get the user_id of the user that was just added
            String queryUserID = "SELECT ID FROM user WHERE email = ? AND phone_number = ? AND Fname = ? AND Lname = ?";
            PreparedStatement stmt2 = conn.prepareStatement(queryUserID);
            stmt2.setString(1, email);
            stmt2.setString(2, phone);
            stmt2.setString(3, firstName);
            stmt2.setString(4, lastName);
            ResultSet rs = stmt2.executeQuery();
            rs.next();
            int userID = rs.getInt("ID");

            // Add the username and password to the user_login table
            String queryLogin = "INSERT INTO user_login (ID, username, User_Password) VALUES (?, ?, ?)";
            PreparedStatement stmt3 = conn.prepareStatement(queryLogin);
            stmt3.setInt(1, userID);
            stmt3.setString(2, username);
            stmt3.setString(3, password);
            stmt3.executeUpdate();

            conn.commit(); // End the transaction
            return 0;

        }
        catch (SQLException e)
        {
            System.out.println("Error adding User: " + e.getMessage());
            try
            {
                conn.rollback();
            }
            catch (SQLException e1)
            {
                JOptionPane.showMessageDialog(null, "Error: " + e1.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            } // Undo the transaction
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

    }

    public static int registerAdmin(String firstName, String lastName, String username, String password)
    {
        conn = getConnection();
        int result = checkUsernameAdmin(username);
        if (result == 1)
        {
            return 1;
        }
        else if (result == -1)
        {
            return -1;
        }

        String queryUser = "INSERT INTO admin (Fname, Lname) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(queryUser))
        {
            conn.setAutoCommit(false); // Start a transaction
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            int checkName = stmt.executeUpdate();
            if (checkName == 0)
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Name already exists", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }

            // Get the user_id of the user that was just added
            String queryUserID = "SELECT ID FROM admin WHERE Fname = ? AND Lname = ?";
            PreparedStatement stmt2 = conn.prepareStatement(queryUserID);
            stmt2.setString(1, firstName);
            stmt2.setString(2, lastName);
            ResultSet rs = stmt2.executeQuery();
            rs.next();
            int userID = rs.getInt("ID");

            // Add the username and password to the user_login table
            String queryLogin = "INSERT INTO admin_Login (ID, username, admin_Password) VALUES (?, ?, ?)";
            PreparedStatement stmt3 = conn.prepareStatement(queryLogin);
            stmt3.setInt(1, userID);
            stmt3.setString(2, username);
            stmt3.setString(3, password);
            stmt3.executeUpdate();

            conn.commit(); // End the transaction
            return 0;

        }
        catch (SQLException e)
        {
            System.out.println("Error adding Admin: " + e.getMessage());
            try
            {
                conn.rollback();
            }
            catch (SQLException e1)
            {
                JOptionPane.showMessageDialog(null, "Error: " + e1.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            } // Undo the transaction
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static TableModel getUsersReservations()
    {
        conn = getConnection();
        String query = "SELECT ReservationID AS ID, ReservationDate AS Date, ReservationEvent AS event, price As Price FROM reservation WHERE user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setInt(1, currentUserID);
            ResultSet rs = stmt.executeQuery();
            return DbUtils.resultSetToTableModel(rs);
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static TableModel getAllReservations()
    {
        conn = getConnection();
        String query = "SELECT User_ID AS UserID, reservationID AS R_ID, ReservationDate AS Date, ReservationEvent AS Event, price As Price FROM reservation";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            ResultSet rs = stmt.executeQuery();
            return DbUtils.resultSetToTableModel(rs);
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int addReservation(String date, String event, double price)
    {
        conn = getConnection();
        String query = "INSERT INTO reservation (User_ID, ReservationDate, ReservationEvent, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setInt(1, currentUserID);
            stmt.setString(2, date);
            stmt.setString(3, event);
            stmt.setDouble(4, price);
            int check = stmt.executeUpdate();
            if (check == 0)
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Reservation already exists", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            return 0;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static TableModel getAllAdmins()
    {
        conn = getConnection();
        String query = "SELECT admin.ID, Fname, Lname, Username FROM admin, admin_login WHERE admin.ID = admin_login.ID";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            ResultSet rs = stmt.executeQuery();
            return DbUtils.resultSetToTableModel(rs);
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int removeAdmin(String ID, String name)
    {
        if (Integer.parseInt(ID) == currentUserID)
        {
            JOptionPane.showMessageDialog(null, "Error: " + "Cannot remove yourself", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return 1;
        }
        conn = getConnection();
        String query = "Select CONCAT(fname, ' ', lname) AS name FROM admin WHERE ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            conn.setAutoCommit(false);
            stmt.setString(1, ID);
            ResultSet rs = stmt.executeQuery();
            if (!rs.next())
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Admin does not exist", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            String fname = rs.getString("name");
            System.out.println(fname);
            if (!fname.equals(name))
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Name Does not match", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            String query2 = "DELETE FROM admin WHERE ID = ?";
            PreparedStatement stmt2 = conn.prepareStatement(query2);
            stmt2.setString(1, ID);
            stmt2.executeUpdate();
            String query3 = "DELETE FROM admin_login WHERE ID = ?";
            PreparedStatement stmt3 = conn.prepareStatement(query3);
            stmt3.setString(1, ID);
            stmt3.executeUpdate();
            conn.commit();
            return 0;
        }
        catch (SQLException e)
        {
            try
            {
                conn.rollback();
            }
            catch (SQLException e1)
            {
                e1.printStackTrace();
            }
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int updateReservation(String date, String event, String ID)
    {
        conn = getConnection();
        String query = "UPDATE reservation SET ReservationDate = ?, ReservationEvent = ?WHERE reservationID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, date);
            stmt.setString(2, event);
            stmt.setString(3, ID);
            int check = stmt.executeUpdate();
            if (check == 0)
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Reservation does not exist", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            return 0;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int removeReservation(String ID)
    {
        conn = getConnection();
        String query = "DELETE FROM reservation WHERE reservationID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, ID);
            int check = stmt.executeUpdate();
            if (check == 0)
            {
                JOptionPane.showMessageDialog(null, "Error: " + "Reservation does not exist", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return 1;
            }
            return 0;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int updateUser(UserModel user)
    {
        conn = getConnection();
        String query = "UPDATE user SET Fname = ?, MName = ?, Lname = ?, Email = ?, phone_number = ? WHERE ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, user.getFirstName());
            stmt.setString(2, user.getMiddleName());
            stmt.setString(3, user.getLastName());
            stmt.setString(4, user.getEmail());
            stmt.setString(5, user.getPhone());
            stmt.setInt(6, currentUserID);
            int result = stmt.executeUpdate();
            if (result == 0)
            {
                JOptionPane.showMessageDialog(null, "Error: " + "User does not exist", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return -1;
            }
            return 0;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int getLastReservationID()
    {
        conn = getConnection();
        String query = "SELECT reservationID FROM reservation ORDER BY reservationID DESC LIMIT 1";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                return rs.getInt("reservationID");
            }
            return -1;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static int addReservationUser(ReservationModel reservationModel)
    {
        conn = getConnection();
        String query = "INSERT INTO reservation (User_ID, ReservationDate, ReservationEvent, price) VALUES (?, ?, ?, ?)";
        try
        {
            conn.setAutoCommit(false);
            PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, currentUserID);
            stmt.setString(2, reservationModel.getEventDate());
            stmt.setString(3, reservationModel.getEventType());
            stmt.setDouble(4, 5000.00);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            int reservationID = 0;
            if (rs.next())
            {
                reservationID = rs.getInt(1);
            }

            String query2 = "INSERT into Payment(ReservationID, total_price, payment_method, user_ID, Card_Number, CardEXP, CCV) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt2 = conn.prepareStatement(query2);
            stmt2.setInt(1, reservationID);
            stmt2.setDouble(2, 5000.00);
            stmt2.setString(3, "Credit Card");
            stmt2.setInt(4, currentUserID);
            stmt2.setString(5, reservationModel.getCardNumber());
            stmt2.setString(6, reservationModel.getCardExp());
            stmt2.setString(7, reservationModel.getCardCVV());
            stmt2.executeUpdate();
            conn.commit();
            return 0;
        }
        catch (SQLException e)
        {
            try
            {
                conn.rollback();
            }
            catch (SQLException e1)
            {
                // TODO Auto-generated catch block
                System.out.println("Error: " + e1.getMessage());
            }
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static TableModel getReservationsPaymentsOfCurrentUser()
    {
        conn = getConnection();
        String query = "SELECT reservation.reservationID, reservation.ReservationDate, reservation.ReservationEvent, reservation.price, payment.payment_method, payment.total_price, payment.Card_Number, payment.CardEXP, payment.CCV FROM reservation INNER JOIN payment ON reservation.reservationID = payment.ReservationID WHERE reservation.User_ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setInt(1, currentUserID);
            ResultSet rs = stmt.executeQuery();
            return DbUtils.resultSetToTableModel(rs);
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return null;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

    }

    public static int checkID(String reservationID)
    {
        conn = getConnection();
        String query = "SELECT reservationID FROM reservation WHERE reservationID = ? AND User_ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setString(1, reservationID);
            stmt.setInt(2, currentUserID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                JOptionPane.showMessageDialog(null, "Reservation ID: " + reservationID + " is valid", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                return 0;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Reservation ID: " + reservationID + " is invalid", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return -1;
            }
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return -1;
        } finally
        {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }
}
