package com.mycompany.bluewaves.Screens;

import java.awt.Color;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import com.mycompany.bluewaves.API.DatabaseManager;

public class EditRemoveReservation extends javax.swing.JFrame
{

    public EditRemoveReservation()
    {
        super("Edit/Remove Reservation");
        this.getContentPane().setBackground(Color.decode("#adc5cf"));
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jPanel1 = new javax.swing.JPanel();
        reservationIDTextField = new javax.swing.JTextField();
        reservationIdLabel = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        optionsLabel = new javax.swing.JLabel();
        totalPriceLabel = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        optionsBox = new javax.swing.JComboBox<>();
        updateButton = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        removeButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        reservationsTable = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));

        setBackground(new java.awt.Color(173, 197, 207));
        setForeground(new java.awt.Color(173, 197, 207));

        reservationIdLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        reservationIdLabel.setText("Reservation ID:");

        dateLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        dateLabel.setText("Date:");

        optionsLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        optionsLabel.setText("Event options:");

        totalPriceLabel.setFont(new java.awt.Font("Serif", 1, 16)); // NOI18N
        totalPriceLabel.setText("Total price:");

        jTextField3.setText("5000SR");
        jTextField3.setEditable(false);

        optionsBox.setModel(
                new javax.swing.DefaultComboBoxModel<>(new String[] {"party", "wedding", "engagement", "birthday"}));

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                updateReservationHandler(evt);
            }
        });

        removeButton.setText("Remove");
        removeButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                removeReservationHandler(evt);
            }
        });

        refreshTable();
        jScrollPane2.setViewportView(reservationsTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(reservationIdLabel)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(reservationIDTextField,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 47,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(optionsLabel)
                                                        .addComponent(optionsBox, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(totalPriceLabel)
                                                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(updateButton,
                                                                javax.swing.GroupLayout.Alignment.TRAILING,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 102,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(46, 46, 46)
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(35, 35, 35)
                                                                .addComponent(removeButton,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE, 102,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(reservationIdLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(reservationIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        26,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(dateLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(optionsLabel)
                                                .addGap(18, 18, 18)
                                                .addComponent(optionsBox, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(totalPriceLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(53, 53, 53)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(removeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(57, Short.MAX_VALUE)));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void refreshTable()
    {
        TableModel model = DatabaseManager.getAllReservations();
        if (model != null)
        {
            reservationsTable.setModel(model);
        }
        else
        {
            reservationsTable.setModel(new javax.swing.table.DefaultTableModel(
                    new Object[][] {
                            {null}
                    },
                    new String[] {
                            "No reservations"
                    }));
        }

    }

    private void updateReservationHandler(java.awt.event.ActionEvent evt)
    {
        String date = new SimpleDateFormat("yyyy-MM-dd").format(jDateChooser1.getDate());
        String option = optionsBox.getSelectedItem().toString();
        String reservationID = reservationIDTextField.getText();
        // Input Validation
        if (reservationID.equals(""))
        {
            JOptionPane.showMessageDialog(null, "Please enter a reservation ID");
            return;
        }
        if (jDateChooser1.getDate() == null)
        {
            JOptionPane.showMessageDialog(null, "Please enter a date");
            return;
        }
        if (option == null)
        {
            JOptionPane.showMessageDialog(null, "Please select an option");
            return;
        }

        // Confirmation
        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this reservation?");
        if (dialogResult == JOptionPane.YES_OPTION)
        {
            // Update reservation
            int result = DatabaseManager.updateReservation(date, option, reservationID);
            if (result == 0)
            {
                JOptionPane.showMessageDialog(null, "Reservation updated successfully");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Reservation update failed");
            }
            refreshTable();
        }
    }

    private void removeReservationHandler(java.awt.event.ActionEvent evt)
    {
        // Confirm
        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this reservation?");
        if (dialogResult == JOptionPane.YES_OPTION)
        {
            // Remove reservation
            String reservationID = reservationIDTextField.getText();
            int result = DatabaseManager.removeReservation(reservationID);
            if (result == 0)
            {
                JOptionPane.showMessageDialog(null, "Reservation removed successfully");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Reservation removal failed");
            }
            refreshTable();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton updateButton;
    private javax.swing.JButton removeButton;
    private javax.swing.JComboBox<String> optionsBox;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel reservationIdLabel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel optionsLabel;
    private javax.swing.JLabel totalPriceLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable reservationsTable;
    private javax.swing.JTextField reservationIDTextField;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
