package com.mycompany.bluewaves.Screens;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;

import com.mycompany.bluewaves.API.DatabaseManager;
import com.mycompany.bluewaves.Models.ReservationModel;

public class PaymentDetails extends JFrame
{
    ImageIcon image;
    JLabel lableimage;
    JTextField name, number, cvv;
    JTextField month, year;
    JLabel labelename, labelnum, m, y, labelcvv;
    JButton submit;
    ReservationModel reservationModel;
    JFrame parent;

    public PaymentDetails(ReservationModel reservationModel, JFrame parent)
    {
        super("Payment Details");
        this.parent = parent;
        this.reservationModel = reservationModel;
        setLayout(new FlowLayout());

        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("Payment-methods.png"))
        {
            BufferedImage image = ImageIO.read(in);
            this.image = new ImageIcon(image);
        }
        catch (IOException e)
        {
            image = null;
            e.printStackTrace();
        }

        labelename = new JLabel("Name on card", image, SwingConstants.CENTER);
        labelename.setHorizontalTextPosition(JLabel.CENTER);
        labelename.setVerticalTextPosition(JLabel.BOTTOM);
        labelnum = new JLabel("Credit Card Number");
        m = new JLabel("Exp month ");
        y = new JLabel("Exp year ");
        labelcvv = new JLabel("cvv");

        submit = new JButton("Submit and  Proceed To Checkout your total  ");
        submit.addActionListener(e -> paymentHandler());

        name = new JTextField("Mr.Mohammad  ", 40);
        number = new JTextField("1111-2222-3333-5555 ", 40);
        month = new JTextField(" 1 ");
        year = new JTextField(" 2022 ");
        cvv = new JTextField("123 ");

        add(labelename);
        add(name);
        add(labelnum);
        add(number);
        add(m);
        add(month);
        add(y);
        add(year);
        add(labelcvv);
        add(cvv);
        add(submit);

        setSize(500, 300); // to set the x-dimension and y-dimension of frame.
        setResizable(false); // To not allow the user to resize the application window.
        setVisible(true); // make frame visible.
        getContentPane().setBackground(Color.decode("#adc5cf"));
    }

    public void paymentHandler()
    {
        PaymentDetails b = this;

        int UserResponse = JOptionPane.showConfirmDialog(b.submit, "Procceed to pay?", "Confirmation",
                JOptionPane.YES_NO_CANCEL_OPTION);

        if (UserResponse == JOptionPane.YES_OPTION)
        {
            reservationModel.setCardNumber(number.getText());
            reservationModel.setCardName(name.getText());
            reservationModel.setCardCVV(cvv.getText());
            reservationModel.setCardExpMonth(month.getText());
            reservationModel.setCardExpYear(year.getText());

            int result = DatabaseManager.addReservationUser(reservationModel);
            if (result == 0)
            {
                JOptionPane.showMessageDialog(b, "Your payment went successfully.");
                dispose();
                parent.dispose();
                return;
            }
            else
            {
                JOptionPane.showMessageDialog(b, "Your payment failed.");
            }
        }

        else if (UserResponse == JOptionPane.NO_OPTION)
        {
            JOptionPane.showMessageDialog(b, "Your payment has been canceled.");
        }
    }

}
