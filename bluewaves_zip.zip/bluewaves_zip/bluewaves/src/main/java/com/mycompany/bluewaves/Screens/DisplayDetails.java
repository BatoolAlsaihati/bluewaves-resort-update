package com.mycompany.bluewaves.Screens;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.mycompany.bluewaves.API.DatabaseManager;
import com.mycompany.bluewaves.Models.ReservationModel;
import com.mycompany.bluewaves.Models.UserModel;

public class DisplayDetails extends JFrame
{
    ReservationModel reservationModel;

    public DisplayDetails(ReservationModel reservationModel)
    {
        super("Reservation Details");
        this.reservationModel = reservationModel;
        initComponents();

        Color col = new Color(173, 197, 207);
        getContentPane().setBackground(col);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jLabel1 = new javax.swing.JLabel();
        nameLabel = new javax.swing.JLabel();
        phoneNumberLabel = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        emailLabel = new javax.swing.JLabel();
        priceLabel = new javax.swing.JLabel();
        payButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        reservationIDLabel = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(173, 197, 207));
        setFocusable(false);
        setForeground(new java.awt.Color(173, 197, 207));

        jLabel1.setFont(new java.awt.Font("Serif", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 51, 51));
        jLabel1.setText("Reservation Details");

        nameLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        nameLabel.setForeground(new java.awt.Color(0, 51, 51));
        nameLabel.setText("Name: ");
        nameLabel.setFocusable(false);

        phoneNumberLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        phoneNumberLabel.setForeground(new java.awt.Color(0, 51, 51));
        phoneNumberLabel.setText("Phone number: +966");
        phoneNumberLabel.setFocusable(false);

        jLabel4.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 51));
        jLabel4.setText("");
        jLabel4.setFocusable(false);

        dateLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        dateLabel.setForeground(new java.awt.Color(0, 51, 51));
        dateLabel.setText("Date:");
        dateLabel.setFocusable(false);

        emailLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        emailLabel.setForeground(new java.awt.Color(0, 51, 51));
        emailLabel.setText("Email: ");
        emailLabel.setFocusable(false);

        priceLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        priceLabel.setForeground(new java.awt.Color(0, 51, 51));
        priceLabel.setText("Total price: 5000");
        priceLabel.setFocusable(false);

        payButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        payButton.setText("Procceed to pay");
        payButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                goToPaymentDetails(evt);
            }
        });

        editButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        editButton.setText("Edit");
        editButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                goToAddRemoveReservation(evt);
            }
        });

        cancelButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                cancelReservation(evt);
            }
        });

        reservationIDLabel.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        reservationIDLabel.setForeground(new java.awt.Color(0, 51, 51));
        reservationIDLabel.setText("Reservation ID: ");
        reservationIDLabel.setFocusable(false);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("bw.png"))
        {
            BufferedImage image = ImageIO.read(in);
            jLabel9.setIcon(new ImageIcon(image));
        }
        catch (IOException e)
        {
            jLabel9 = null;
            e.printStackTrace();
        }
        jLabel9.setText(" ");

        addInformation();

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(29, 29, 29)
                                                .addGroup(
                                                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(phoneNumberLabel)
                                                                .addComponent(nameLabel)
                                                                .addComponent(jLabel4)
                                                                .addComponent(dateLabel)
                                                                .addComponent(emailLabel)
                                                                .addComponent(priceLabel)
                                                                .addGroup(layout.createSequentialGroup()
                                                                        .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addComponent(reservationIDLabel)
                                                                                .addComponent(jLabel1))
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(jLabel9,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 197,
                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(60, 60, 60)
                                                .addComponent(payButton)
                                                .addGap(36, 36, 36)
                                                .addComponent(editButton, javax.swing.GroupLayout.PREFERRED_SIZE, 114,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(36, 36, 36)
                                                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 114,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(60, Short.MAX_VALUE)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap(20, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(35, 35, 35)
                                                .addComponent(reservationIDLabel))
                                        .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(30, 30, 30)
                                .addComponent(nameLabel)
                                .addGap(30, 30, 30)
                                .addComponent(phoneNumberLabel)
                                .addGap(30, 30, 30)
                                .addComponent(emailLabel)
                                .addGap(30, 30, 30)
                                .addComponent(jLabel4)
                                .addGap(30, 30, 30)
                                .addComponent(dateLabel)
                                .addGap(30, 30, 30)
                                .addComponent(priceLabel)
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(payButton)
                                        .addComponent(editButton)
                                        .addComponent(cancelButton))
                                .addContainerGap(20, Short.MAX_VALUE)));

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {payButton, editButton, cancelButton});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addInformation()
    {
        UserModel user = DatabaseManager.getCurrentUser();
        nameLabel.setText("Name: " + user.getFirstName() + " " + user.getLastName());
        phoneNumberLabel.setText("Phone Number: " + user.getPhone());
        emailLabel.setText("Email: " + user.getEmail());
        reservationIDLabel.setText("Reservation ID: " + reservationModel.getReservationID());
        dateLabel.setText("Date: " + reservationModel.getEventDate());

    }

    protected void cancelReservation(ActionEvent evt)
    {
        int UserResponse = JOptionPane.showConfirmDialog(editButton, "Are you sure you want to cancel your reservation?",
                "Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);

        if (UserResponse == JOptionPane.YES_OPTION)
        {
            JOptionPane.showMessageDialog(editButton, "Your reservation has been canceled.");
            dispose();
        }
    }

    private void goToPaymentDetails(java.awt.event.ActionEvent evt)
    {// GEN-FIRST:event_jButton1ActionPerformed
        PaymentDetails i = new PaymentDetails(reservationModel, this);
        i.setSize(500, 300); // to set the x-dimension and y-dimension of frame.
        i.setResizable(false); // To not allow the user to resize the application window.// exit out of application.
        i.setVisible(true); // make frame visible.
        i.getContentPane().setBackground(Color.decode("#adc5cf"));
        i.setLocationRelativeTo(null); // center application on screen.
    }// GEN-LAST:event_jButton1ActionPerformed

    private void goToAddRemoveReservation(java.awt.event.ActionEvent evt)
    {
        dispose();
        AddRemoveReservation i = new AddRemoveReservation(reservationModel);
        i.setVisible(true);
        i.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton payButton;
    private javax.swing.JButton editButton;
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JLabel phoneNumberLabel;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JLabel priceLabel;
    private javax.swing.JLabel reservationIDLabel;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
